﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace MDTSample
{
    /// <summary>
    /// Summary description for mdtsample
    /// </summary>
    [WebService(Namespace = "http://contoso.com/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class mdtsample : System.Web.Services.WebService
    {

        [WebMethod]
        public string GetComputerName(String Model, String SerialNumber)
        {
            string sGetComputerName;
            string TrimmedSerialNumber;

            TrimmedSerialNumber = SerialNumber;

            if (SerialNumber.Length > 12)
            {
                TrimmedSerialNumber = SerialNumber.Substring(0, 12);
            }

            switch (Model)
            {
                case "Hewlett-Packard":
                    sGetComputerName = "HP" + TrimmedSerialNumber;
                    break;
                case "Dell Inc.":
                    sGetComputerName = "DL" + TrimmedSerialNumber;
                    break;
                default:
                    // No matching model found
                    sGetComputerName = "NN" + TrimmedSerialNumber;
                    break;

            }

            return sGetComputerName;

        }
    }
}
